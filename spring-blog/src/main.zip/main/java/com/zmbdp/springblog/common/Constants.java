package com.zmbdp.springblog.common;

public class Constants {
    public static final Integer RESULT_SUCCESS = 200;
    public static final Integer RESULT_FAIL = -1;
}
